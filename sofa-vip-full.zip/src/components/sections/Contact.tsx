export default function Contact() {
  return (
    <section className="p-16 text-center">
      <h2 className="text-4xl text-[#d4af37] mb-6">تواصل معنا</h2>
      <a href="tel:+9647881457896" className="block text-lg">اتصال مباشر</a>
    </section>
  );
}
