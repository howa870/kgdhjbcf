export default function Footer() {
  return (
    <footer className="p-6 text-center text-gray-500 border-t border-[#d4af37]/20">
      © 2026 جميع الحقوق محفوظة
    </footer>
  );
}
