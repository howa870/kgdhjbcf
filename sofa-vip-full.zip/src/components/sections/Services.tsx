export default function Services() {
  return (
    <section className="p-16 text-center">
      <h2 className="text-4xl text-[#d4af37] mb-6">خدماتنا</h2>
      <p className="text-gray-400">تفصيل - صيانة - تصميم</p>
    </section>
  );
}
