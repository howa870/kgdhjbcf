export default function Hero() {
  return (
    <section className="min-h-screen flex items-center justify-center text-center bg-black">
      <div>
        <h1 className="text-6xl font-bold text-[#d4af37]">قنفات ودواوين فخمة</h1>
        <p className="mt-6 text-xl text-gray-300">تفصيل حسب الطلب بأعلى جودة</p>
        <a href="https://wa.me/9647881457896" className="inline-block mt-8 bg-[#d4af37] text-black px-8 py-4 rounded-lg font-bold">
          اطلب الآن
        </a>
      </div>
    </section>
  );
}
