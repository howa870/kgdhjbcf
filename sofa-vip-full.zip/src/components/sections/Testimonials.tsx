export default function Testimonials() {
  return (
    <section className="p-16 text-center">
      <h2 className="text-4xl text-[#d4af37] mb-6">آراء العملاء</h2>
      <p className="text-gray-400">"شغلهم ممتاز جداً"</p>
    </section>
  );
}
