import { useState } from "react";

export default function Gallery() {
  const [images] = useState([
    "https://images.unsplash.com/photo-1555041469-a586c61ea9bc",
    "https://images.unsplash.com/photo-1505691938895-1758d7feb511",
    "https://images.unsplash.com/photo-1493666438817-866a91353ca9"
  ]);

  return (
    <section className="p-16">
      <h2 className="text-4xl mb-10 text-center text-[#d4af37]">المعرض</h2>
      <div className="grid md:grid-cols-3 gap-6">
        {images.map((img,i)=>(
          <img key={i} src={img} className="rounded-xl hover:scale-105 transition"/>
        ))}
      </div>
    </section>
  );
}
