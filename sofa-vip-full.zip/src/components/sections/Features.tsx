export default function Features() {
  const data = [
    { title: "جودة عالية" },
    { title: "تفصيل حسب الطلب" },
    { title: "توصيل سريع" },
  ];
  return (
    <section className="p-16 grid md:grid-cols-3 gap-8 text-center">
      {data.map((f,i)=>(
        <div key={i} className="bg-[#1a1a1a] p-6 rounded-xl border border-[#d4af37]/20">
          <h3 className="text-xl text-[#d4af37]">{f.title}</h3>
        </div>
      ))}
    </section>
  );
}
