import Hero from "../components/sections/Hero";
import Features from "../components/sections/Features";
import Gallery from "../components/sections/Gallery";
import Services from "../components/sections/Services";
import Testimonials from "../components/sections/Testimonials";
import Contact from "../components/sections/Contact";
import Footer from "../components/sections/Footer";

export default function Home() {
  return (
    <div className="bg-[#0a0a0a] text-white" dir="rtl">
      <Hero />
      <Features />
      <Gallery />
      <Services />
      <Testimonials />
      <Contact />
      <Footer />
    </div>
  );
}
